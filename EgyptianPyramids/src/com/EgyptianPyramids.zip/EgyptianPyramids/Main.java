package com.EgyptianPyramids;

import java.io.BufferedReader;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {

        PyramidsDAO DAO = new PyramidCSVDAO();

       ArrayList<Pyramid>  pyramids = DAO.readPyramidsFromCsv();

        for ( Pyramid pyramid : pyramids) {
            System.out.println("Pyramid no "+(pyramids.indexOf(pyramid)+1));
            System.out.println("Pharaoh :"+pyramid.getPharaoh());
            System.out.println("Ancient_name :"+pyramid.getAncient_name());
            System.out.println("Base1 :"+pyramid.getBase1());
            System.out.println("Base2 :"+pyramid.getBase2());
            System.out.println("Height :"+pyramid.getHeight());
            System.out.println("Site :"+pyramid.getSite());
            System.out.println("Volume :"+pyramid.getVolume());
            System.out.println("Slope :"+pyramid.getSlope());
            System.out.println("-------------------------------------");




        }

    }
}
